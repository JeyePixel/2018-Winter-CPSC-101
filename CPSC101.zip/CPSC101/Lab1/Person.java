/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package homework1;

/**
 *
 * @author heales
 */
import java.util.ArrayList;
public class Person {
    
    //Here we are declaring all of the variables we will need for our methods and constructor
    private String name;
    private boolean isAlive;
    private static ArrayList<Person> population = new ArrayList<Person>();
    private Person murderer;
    private static int numberLiving = 0;
    private static int numberDead = 0;
    
    //Here is our constructor
    public Person (String n){
        name = n;
        isAlive = true;
        population.add(this);//This will add our person object to our ArrayList
        numberLiving++;
        murderer = null;
    }
    
    //This method will return the name of the murderer of a dead Person
    public String murderer(){
        if(isAlive)
            return null;//If a person is alive,they will have no murderer
        else
            return murderer.name;    
    }
    
    //This method will return the name of a Person and tell if they are deceased
    public String name(){
        if(isAlive)
            return name;
        else 
            return name + ", deceased";
    }
    
    //This method will tell us if a Person is alive
    public boolean isAlive(){
        return isAlive;
    }
    
    //This method will cause a Person to die
    public void die(){
        isAlive = false;
        numberLiving--;
        numberDead++;
    }
    
    //This method will cause a Person to murder another Person
    public void murder(Person a){
        a.isAlive = false;
        a.murderer = this;//This line sets the murderer of Person n to whoever called the method
        numberLiving--;
        numberDead++;
    }
    
    //This method will cause a living Person to say hello
    public void sayHello(){
        if(isAlive)
            System.out.println("\"Hello, I'm " + name + ".\"");   
    }
    
    //This method will cause every living Person to say hello
    public static void allSayHello(){
        for(Person people : population){   
            people.sayHello();
        }
    }
    
    //This method will return the number of living Persons
    public static int numberLiving(){
        return numberLiving;
    }
    
    //This method will return the number of dead Persons
    public static int numberDead(){
        return numberDead;
    }  
}
