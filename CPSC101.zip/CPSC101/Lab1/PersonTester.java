/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework1;

/**
 *
 * @author heales
 */
public class PersonTester {
    public static void main(String[] args){
        
        Person a = new Person("Bob");
        Person b = new Person("Dale");
        Person c = new Person("Louis");
        Person d = new Person("George");
        Person e = new Person("Angela");
        
        System.out.println("5 strangers walk into a room. They introduce themselves to one another.");
        
        Person.allSayHello();//testing the allSayHello method
        
        b.sayHello();//testing the sayhello method
        
        System.out.println("\"We heard you the first time, Dale.\", says Bob");
        
        System.out.println("\"There are " + Person.numberLiving() + " people here right now\", Says Bob.");//testing the numberLiving method
        
        System.out.println("\"Not for long!\" Dale yells, and holds up his hand with his fingers in the shape of a gun.");
        
        System.out.println("\"Surely you are joking!\" Says George, and Dale pivots to face him, pointing directly at his head.");
        
        System.out.println("BANG!");
        
        b.murder(d);//Testing the murder method
        
        System.out.println("\"Holy Moly!\", said Angela.\"is George alive anymore?\"");
        
        System.out.println("\"" + d.isAlive() + "!\" Says Louis");//testing the isAlive method
        
        System.out.println("\"And you're next!\", says Dale.BANG!");
        
        b.murder(c);
        
        System.out.println("\"This is unbelievable! " + c.murderer() + " just murdered Louis AND George!\" Says Angela.");//testing the murderer method
        
        System.out.println("\"I'm sorry, I just got amnesia. What is my name?\" Says Dale");
        
        System.out.println("\"Your name is " + b.name() + ", and you just murdered " + Person.numberDead() + " people!\" Says Angela");//Testing the name method and the numberofDead method
      
        System.out.println("Suddenly, bob clutched at his chest and crumpled to the floor!");
        
        a.die();//testing the die method
        
        System.out.println("\"And look! Now poor old Bob has gone and died of fright!\", Says Angela.");
        
        System.out.println("\"Huh. I forgot what i came in this room for.\" , says Dale. He then turns and strides out.");
        
        System.out.println("FIN");
        
        
        
    }
    
}
