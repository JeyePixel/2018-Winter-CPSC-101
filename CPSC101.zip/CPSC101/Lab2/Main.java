
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

/**
 *
 * @author heales
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.File;
import java.io.FileNotFoundException;
public class Main { 
    
    //This ArrayList will hold all of the words that Scanner is passed
    public static ArrayList<String> wordlist = new ArrayList<>();
    
    //This ArrayList will hold all of the words with the specified number of consecutive pairs
    public static ArrayList<String> correctwords = new ArrayList<>();
    
    public static void main(String[] args) throws FileNotFoundException{
        
    //We need to first declare all variables and objects we need
    int test;//This will be the number of consecutive pairs
    Scanner in;
    PrintWriter out;
    File f;
    //We need to set up a default scenario if we don't take in enough arguments from the command line
        switch(args.length){
            case 1: test = Integer.parseInt(args[0]);
                    in = new Scanner(System.in);
                    out = new PrintWriter(System.out);
                    break;
            case 2: test = Integer.parseInt(args[0]);
                    f = new File(args[1]);
                    in = new Scanner(f);
                    out = new PrintWriter(System.out);
                    break;
            case 3: test = Integer.parseInt(args[0]);
                    f = new File(args[1]);
                    in = new Scanner(f);
                    out = new PrintWriter(args[2]);
                    f = new File(args[2]);
                    break;
            default: test = 3;
                    in = new Scanner(System.in);
                    out = new PrintWriter(System.out);
                    break;
        }
        
        Main.bookkeeper(test, in, out);
         
           // for(String s: wordlist)
           //     System.out.println(s);
            
          //  System.out.println("-----------");
          //  for(String s: correctwords)
           //     System.out.println(s);
    }
    
    public static void bookkeeper(int n, Scanner in, PrintWriter out){
        Main.fileRead(in);//This method first reads the file and stores all Strings into wordlist
        Main.wordCheck(n, out);//Using pairCheck, wordCheck will iterate through the array, adding each correct word into the array correctwords
        Main.printOut(out);//Finally, bookkeeper uses printOut to print to the specified file 
    }
    
    public static void fileRead(Scanner in){
        while(in.hasNextLine()){//Checks to make sure there are Strings to pass to Scanner
            String word = in.nextLine();
            wordlist.add(word);//Adds the scanned word into our ArrayList "wordlist" 
           
        }
    }
    
    public static void wordCheck(int consecpairs, PrintWriter out){
        wordlist.stream().filter((word) -> (Main.pairCheck(consecpairs, word, out))).forEach((word) -> {
            correctwords.add(word);//This will add all words with the correct number of consecutive pairs to ccorrectwords Arraylist
        });
    }
    
    public static boolean pairCheck(int consecpairs, String word, PrintWriter n){
        int pairs = 0;//This int will keep track of the number of consecutive pairs 
        int maxPairs = 0;//This int will keep track of the max number of consecutive pairs in a  string
        for(int i = 0; i < (word.length() - 1); i++){ 
            char letter1 = word.charAt(i);
            char letter2 = word.charAt(i + 1);
            //n.println("CHAR1: " + letter1 + "\n Char2:"+ letter2);
            if(letter1 == letter2){
                pairs++;
                maxPairs = Math.max(pairs, maxPairs);
                i++;
            }
            else{
                maxPairs = Math.max(pairs, maxPairs);   
                pairs = 0;
            }
            //n.printf("Pairs: %d MaxPairs%d", pairs, maxPairs + "\n");
        }
        return maxPairs == consecpairs;
    }
    
    public static void printOut(PrintWriter out){
        correctwords.stream().forEach((_item) -> {
            out.println(_item);
            out.flush();
        });
    }
}