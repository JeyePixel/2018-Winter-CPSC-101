/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ianheales_assignment3;

/**
 *
 * @author heales
 */
public class Machine {
    
    //Start state for our finite states machine
    private static MachineState currentState;
    
    //This method will reset our finite states machine
    public static void reset() { currentState = MachineState.NOVOWEL ;}
    
    //This method will change the state based upon the input recieved
    public static void acceptChar(char c){
        switch(c){
            case 'a': currentState = (currentState==MachineState.NOVOWEL) ? MachineState.ASEEN : MachineState.REJECT;
                break;
            case 'e': currentState = (currentState==MachineState.ASEEN) ? MachineState.ESEEN : MachineState.REJECT;
                break;
            case 'i': currentState = (currentState==MachineState.ESEEN) ? MachineState.ISEEN : MachineState.REJECT;
                break;
            case 'o': currentState = (currentState==MachineState.ISEEN) ? MachineState.OSEEN : MachineState.REJECT;
                break;
            case 'u': currentState = (currentState==MachineState.OSEEN) ? MachineState.USEEN : MachineState.REJECT;
                break;
        }
    }
    
    //This method will tell us if the finite states machine is in an accepting state
    public static boolean isAccepting() { return (currentState==MachineState.USEEN) ;}
    
    //Machine constructor
    public Machine(){
        reset();
    }
        
    
    
    
    
}
