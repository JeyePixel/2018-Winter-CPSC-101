/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ianheales_assignment3;

/**
 *
 * @author heales
 */
public class Machine2 {
    
    private static State2 currentState;
    
    //This method will reset the finite state machine to a starting point
    public static void reset(){ currentState = State2.initialState ; }
    
    //machine constructor
    public Machine2(){ reset(); }
}
