/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ianheales_assignment3;

/**
 *
 * @author heales
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.File;
import java.io.FileNotFoundException;
public class Main {
    
    //This ArrayList will hold all of the words that Scanner is passed
    public static ArrayList<String> wordlist = new ArrayList<>();
    
    //This ArrayList will hold all of the words that are abstemious
    public static ArrayList<String> correctwords = new ArrayList<>();
    
    public static void main(String[] args) throws FileNotFoundException{
        
        //Create objects of all classes needed to set up our scenarios
        Scanner in;
        PrintWriter out;
        File f;
        Machine finite = new Machine();
        
        //Use a switch statement to set up our default scenarios
        switch(args.length){
            case 0: 
                    in = new Scanner(System.in);
                    out = new PrintWriter(System.out);
                    break;
            case 1: 
                    f = new File(args[0]);
                    in = new Scanner(f);
                    out = new PrintWriter(System.out);
                    break;
            case 2: 
                    f = new File(args[0]);
                    in = new Scanner(f);
                    out = new PrintWriter(args[1]);
                    break;
            default: 
                    in = new Scanner(System.in);
                    out = new PrintWriter(System.out);
                    break;
        }
        Main.fileRead(in);
        Main.vowelCheck();
        Main.printOut(out);
    }  
    
    //This method will read in the words in our txt file to an arraylist
    public static void fileRead(Scanner in){
        while(in.hasNextLine()){//Checks to make sure there are Strings to pass to Scanner
            String word = in.nextLine();
            if(word.equals("-exit"))//Use -exit to stop the Scanner from accepting more words
                break;
            wordlist.add(word);
        }
    }
    
    //This method will scan through the arraylist finding all abstemious words
    public static void vowelCheck(){
        for(String word: wordlist){
            if(isAbstemious(word))
                correctwords.add(word);//This will add the abstemious words into an arraylist     
        }
    }
    
    //This method will check to see if a word is abstemious
    public static boolean isAbstemious(String s){
        Machine.reset();//Resets the finite states machine to a starting point
        for(char c : s.toLowerCase().toCharArray())//Convert the String into an array of characters to evaluate
            //We use .toLowerCase so that our method acceptChar will recieve the correct input
            Machine.acceptChar(c);
        return Machine.isAccepting();
    }
    
    //This method will use PrintWriter to print out all abstemious words
    public static void printOut(PrintWriter out){
        correctwords.stream().forEach((_item) -> {
            out.println(_item);
            out.flush();
        });
    }
}
