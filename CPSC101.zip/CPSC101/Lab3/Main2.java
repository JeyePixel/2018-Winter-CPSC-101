/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ianheales_assignment3;

/**
 *
 * @author heales
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.File;
import java.io.FileNotFoundException;
public class Main2 {
    
    //This ArrayList will hold all of the words that Scanner is passed
    public static ArrayList<String> wordlist = new ArrayList<>();
    
    //This ArrayList will hold all of the words that are abstemious
    public static ArrayList<String> correctwords = new ArrayList<>();
    
    public static void main(String[] args) throws FileNotFoundException{
        
        //Create objects of all classes needed to set up our scenarios
        Scanner in;
        PrintWriter out;
        File f;
        Machine finite = new Machine();
        
        //Use a switch statement to set up our default scenarios
        switch(args.length){
            case 0: 
                    in = new Scanner(System.in);
                    out = new PrintWriter(System.out);
                    break;
            case 1: 
                    f = new File(args[0]);
                    in = new Scanner(f);
                    out = new PrintWriter(System.out);
                    break;
            case 2: 
                    f = new File(args[0]);
                    in = new Scanner(f);
                    out = new PrintWriter(args[1]);
                    break;
            default: 
                    in = new Scanner(System.in);
                    out = new PrintWriter(System.out);
                    break;
        }
        Main.fileRead(in);
        Main.printOut(out);
    }  
    
    //This method will read in the words in our txt file to an arraylist
    public static void fileRead(Scanner in){
        while(in.hasNextLine()){//Checks to make sure there are Strings to pass to Scanner
            String word = in.nextLine();
            if(word.equals("-exit"))//Use -exit to stop the Scanner from accepting more words
                break;
            wordlist.add(word);
        }
    }
    
    //This method will use PrintWriter to print out all degenerative words
    public static void printOut(PrintWriter out){
        correctwords.stream().forEach((_item) -> {
            out.println(_item);
            out.flush();
        });
    }
}