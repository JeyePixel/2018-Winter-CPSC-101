/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ianheales_assignment3;

/**
 *
 * @author heales
 */
public class State2 {
    
    private boolean inInit;
    private boolean amStuck;
    private int consonantCount;
    private char lastConsonant;
    
    //4 argument constructor to initialize our private variables
    public State2(boolean inInit, boolean amStuck, int consonantCount, char lastConsonant){}
    
    
    //Initial state constructor
    public static State2 initialState = new State2(true,false,0,'@');
    
    //Stuck state constructor
    public static State2 stuckState = new State2(false,true,0,'@');
    
    //This method checks to see if our finite states machine is in an accepting state
    public boolean isAcceptingState(){ return (!amStuck && consonantCount>=6) ;}
    
    //This method will tell us if a character c is a consonant
    private static boolean isConsonant(char c){ return ("bcdfghjklmnpqrstvwxz".indexOf(c,0)>-1);}
    
    //This method will take input and determine what state the finitne states machine will advance to
    public State2 nextState(char c){
        if (amStuck || ! isConsonant(c)) return this;
        else if (inInit || c>lastConsonant)
            return new State2(false,false,1+consonantCount,c);
        else
            return stuckState;
    }
}
