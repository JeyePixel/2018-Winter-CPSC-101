/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

/**
 *
 * @author heales
 */
import version1.Time;
public class Main
{
    public static void main(String [] args)
    {
        //Here are all 3 types of constructors in the Time class
        Time timedefault = new Time();//This is the default constructor
        Time time1 = new Time(12,34,5);
        Time time2 = new Time(time1);//This will have the same private member variables as time1
        Time time3 = new Time(13,35,6);
        
        //testing the accesor methods
        System.out.println(timedefault.getHours());//This will print "0"
        System.out.println(time1.getMinutes() + " " + time2.getMinutes());//This will print "34 34"
        System.out.println(time3.getHours() + " " +time3.getMinutes() + " " + time3.getSeconds());//This will print out "13 35 6"
        System.out.println(time2.toString());//This will print out "12:34:5"
        System.out.println(time2.equals(time1));//This will print "true"
        System.out.println(time3.equals(timedefault));//This will print "false"
        
        //We will compare compareTo() and advanceBy() back to back later in the program
        
        //testing the mutator methods
        timedefault.setHour(3);//The hour member variable of timedefault is now 3
        timedefault.setMinute(23);//The minutes variable of timedefault is now 23
        timedefault.setMinute(65);//This will print "Please enter a valid minute from 0 to 59"
        
        //testing advanceBy() and compareTo()
        System.out.println(time2.compareTo(time3) + " seconds");//This will print "3661 seconds"
        time2.advanceBy(3661);//This will add 3661 seconds to time2
        System.out.println(time2.toString());//This will print "13:35:6"
        
        //Testing converting a Time into a String
        System.out.println("The time is " + time3);//This will print 'The time is 13:35:6"
    }
    
}
