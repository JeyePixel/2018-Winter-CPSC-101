/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package version1;

/**
 *
 * @author heales
 */
public class Time
{
    //3 private member variables vital for telling time
    private int hours;
    private int minutes;
    private int seconds;
    
    //3 constructors for Time class
    public Time(){}//The blank constructor will set Time to midnight (0:0:0)
    public Time(int h, int m, int s)//This constructor will take in an hour, minute, and second
    {
        if( h > 24 || h < 0){System.out.println("Please enter a valid hour from 0 to 23");}
        else{hours = h;}
        if( m > 59 || m < 0){System.out.println("Please enter a valid minute from 0 to 59");}
        else{minutes = m;}
        if( s > 59 || s < 0){System.out.println("Please enter a valid second from 0 to 59");}
        else{seconds = s;}       
    }
    public Time(Time t)//This constructor will initialize the same values as a Time object
    {      
        hours = t.hours;
        minutes = t.minutes;
        seconds = t.seconds;       
    }
    
    //Accesor methods
    public int getHours(){ return hours;}//This method returns the hour, ranging from 0 to 23
    public int getMinutes(){ return minutes;}//This method returns the minute, ranging from 0 to 59 
    public int getSeconds(){ return seconds;}//This method returns to second, ranging from 0 to 59
    public String toString()//This method will return the Time as a String
    {
        return Integer.toString(hours) + ":" + Integer.toString(minutes) + ":" + Integer.toString(seconds);
    }
    public boolean equals(Time t)
    {
        return hours == t.hours && minutes == t.minutes && seconds == t.seconds;
    }
    public int compareTo(Time t)//This method will return the difference between 2 times in seconds
    {
        //We will use these variables to calculate the degree of seperation between 2 Times
        int comparisonhours;
        int comparisonminutes;
        int comparisonseconds;
        
        //First, find the difference in hours, minutes, and seconds
        comparisonhours = (hours > t.hours) ? (hours - t.hours) : (t.hours - hours);
        comparisonminutes = (minutes > t.minutes) ? (minutes - t.minutes) : (t.minutes - minutes);
        comparisonseconds = (seconds > t.seconds) ? (seconds - t.seconds) : (t.seconds - seconds);
        
        //Now, iterate through the hours and minutes
        while(comparisonhours > 0)
        {
            --comparisonhours;//Lines 64 and 65 convert the hours into minutes
            comparisonminutes+= 60;
        }
        while(comparisonminutes > 0)
        {
            --comparisonminutes;//Lines 69 and 70 convert minutes into seconds
            comparisonseconds+= 60;
        }
        
        return comparisonseconds;
    }
    
    //Mutator methods
    public void setHour(int h)//This method will set an hour from 0 to 23
    {
        if( h > 24 || h < 0 ){System.out.println("Please enter a valid hour from 0 to 23");}
        else{hours = h;}
    }
    public void setMinute(int m)//This method will set the minute from 0 to 59
    {
        if( m > 59 || m < 0 ){System.out.println("Please enter a valid minute from 0 to 59");}
        else{minutes = m;}
    }
    public void setSecond(int s)//This methods will set the second from 0 to 59
    {
        if( s > 59 || s < 0 ){System.out.println("Please enter a valid second from 0 to 59");}
        else{seconds = s;}
    }
    public void advanceBy(int s)//This method will advance Time by the specified seconds
    {
        seconds += s;
        while ( seconds > 59 )
        {
            seconds -= 60;
            ++minutes;
        }
        while (minutes > 59)
        {
            minutes -= 60;
            ++hours;
        }
        while( hours > 24 ){hours -= 24;}
    } 
}