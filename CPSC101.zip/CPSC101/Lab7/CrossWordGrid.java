package cpsc101.lab7.heales;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class CrossWordGrid extends JPanel
{
	//We need to create an object of WordList in order to get the row number and column number from FileReader
	WordList entries = new WordList();
	
	//Sets the width and height equal to the row and column number in FileReader
	int panelWidth = entries.fileIn.column;
	int panelHeight = entries.fileIn.row;
	
	//Sets the number of child objects, gridSquares, to create
	int gridSquares = panelWidth * panelHeight;
	
	public CrossWordGrid()
	{
		this.setSize((40 * panelHeight) + 6, (40 * panelWidth) + 6);
		this.setLayout(null);//Sets the layout manager to null
		for(int i = 0; i < gridSquares; i++)//Creates row * column child objects
		{
			GridSquares cell;
		}
	}
	
	//Override so we can paint the background dark gray
	@Override
	public void paintComponent(Graphics g){this.setBackground(Color.DARK_GRAY);}

}
