package cpsc101.lab7.heales;

import javax.swing.Box;
//Contains CrosswordGrid and 2 WordBoxes
public class Crossword extends Box
{

}
