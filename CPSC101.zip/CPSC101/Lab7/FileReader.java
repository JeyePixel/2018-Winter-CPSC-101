package cpsc101.lab7.heales;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class FileReader 
{	
	//This ArrayList holds 'row' Strings of length 'column'
	static ArrayList<String> rowEntries = new ArrayList<String>();
	
	int row = 0;
	int column = 0;
	int linecount = 0;
	File file = new File("/home/heales/Desktop/in.txt");
	Scanner sc;
	//readFile scans file
	public void readFile() throws FileNotFoundException
	{
		sc = new Scanner(file);
		while(sc.hasNextLine())//Checks for an available line
		{
			linecount++;//Keeps track of the number of lines in the file
			switch(linecount)
			{
			case 1: row = sc.nextInt();//Sets the row number
					break;
			case 2: column = sc.nextInt();//Sets the column number
			sc.nextLine();
					break;
			default: for(int i=0 ; i < row ; i++){rowEntries.add(sc.nextLine());}
				     break;
			}
		}
		sc.close();//Closes the file
		linecount = 0;//Resets the line count
	}
	//Getter method for rowEntries
	public ArrayList<String> getRowEntries(){return rowEntries;}
}
