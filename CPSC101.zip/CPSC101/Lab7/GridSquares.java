package cpsc101.lab7.heales;

import java.awt.Graphics;

import javax.swing.JComponent;

public class GridSquares extends JComponent
{
	private boolean isBlack;
	private char letter;
	private boolean isNumbered;
	private int number;
	
	public GridSquares()
	{
		this.setSize(40,40);//All GridSquares have size 40x40
		
	}
	
	@Override
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		if(isBlack)//Checks to see if the GridSquare is black
		{
			
		}
		if(isNumbered)//Checks to see if the GridSquare has a number
		{
			
		}
	}
	
	

}
