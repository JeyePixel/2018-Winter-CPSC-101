package cpsc101.lab7.heales;

import javax.swing.JLabel;
import java.awt.Font;

public class ListTitle extends JLabel
{
	//The title Font is very similar to the WordList Font
	Font listTitleFont = new Font("Courier", Font.BOLD, 16);
	
	public ListTitle()
	{
		this.setFont(getListTitleFont());
		this.setAlignmentX(LEFT_ALIGNMENT);
	}

	//Getter method for listTitleFont
	public Font getListTitleFont(){return listTitleFont;}
}
