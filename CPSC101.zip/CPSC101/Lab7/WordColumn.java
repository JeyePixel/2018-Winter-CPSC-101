package cpsc101.lab7.heales;

import javax.swing.JPanel;
import javax.swing.BoxLayout;

public class WordColumn extends JPanel
{
	//WordList object to be added to WordColumn
	WordList wordList = new WordList();
	
	//ListTitle object to be added to WordColumn
	ListTitle listTitle = new ListTitle();
	
	//CrossWord object to be added to WordColumn
	CrossWord crossWord = new CrossWord(BoxLayout.Y_AXIS);
	
	//WordColumn constructor
	public WordColumn()
	{
		this.add(wordList);
		this.add(listTitle);
		this.setLayout(new BoxLayout(crossWord, BoxLayout.Y_AXIS));
	}
}
