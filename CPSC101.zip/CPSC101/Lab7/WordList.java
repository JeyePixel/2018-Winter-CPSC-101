package cpsc101.lab7.heales;

import javax.swing.JTextArea;

import java.awt.Font;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class WordList extends JTextArea
{
	//Object of FileReader to get rowEntries
	FileReader fileIn = new FileReader();
	
	//This is the Font we will be using
	Font wordListFont = new Font("Courier", Font.PLAIN, 14);
	
	//Constructor for WordList
	public WordList()
	{
		this.setEditable(false);
		this.setFont(getWordListFont());
		this.setAlignmentX(LEFT_ALIGNMENT);
	}
	
	//getter method for wordListFont
	public Font getWordListFont(){return wordListFont;}
	
	//ArrayList to hold the rowEntries ArrayList passed from FileReader
	ArrayList<String> rowEntries = fileIn.getRowEntries();
	
	//ArrayList to hold the column entries found in rowEntries
	ArrayList<String> columnEntries = new ArrayList<String>();
	
	//ArrayList to hold letters of a word. Will be used to make columnEntries
	ArrayList<Character> letters = new ArrayList<Character>();
	
	//Advanced-for loop and append method to add all entries of rowEntries to WordList
	public void addRowEntries() throws FileNotFoundException
	{
		fileIn.readFile();
		for(String entry : rowEntries)
		{
			String[] xEntry = entry.split("X");
			for(String word : xEntry)
			{
				if(word.length() > 1){
					this.append(word + "\n");//If a word's length is greater than 1, append it to WordList
				}
			}	
		}
	}
	public void addColumnEntries() throws FileNotFoundException
	{
	fileIn.readFile();
	char[][] charArray = new char[fileIn.row][fileIn.column];
	for(int j = 0; j < fileIn.column; j++)
	{
		for(int i = 0; i < fileIn.column; i++)
		{
			charArray[i][j] = rowEntries.get(j).charAt(i);
		}
	}
	for(char[] x : charArray)
	{
		for(char thing : x)
		{
			System.out.print(thing);
		}
		System.out.println(" ");
	}
	StringBuilder columnEntry = new StringBuilder(fileIn.row);
	for(char[] charword: charArray)//Each element inside of charArray is getting turned into a String
	{
		columnEntry.append(charword);
		this.append(columnEntry.toString() + "\n");//Appends the word to WordList
		columnEntry.delete(0, fileIn.row);
	}
	
	}
}
