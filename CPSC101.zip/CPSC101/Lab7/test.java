package cpsc101.lab7.heales;

import java.io.FileNotFoundException;

import javax.swing.JFrame;

public class test {
	public static void main(String [] args) throws FileNotFoundException
	{
	WordList list = new WordList();
	WordList secondList = new WordList();
	secondList.addRowEntries();
	list.addColumnEntries();
	JFrame frame = new JFrame();
	frame.setSize(1000,1000);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.add(list);
	frame.add(secondList);
	
	frame.setVisible(true);	
	}

}
