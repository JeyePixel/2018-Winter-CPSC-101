package cpsc101.lab8.heales;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;

public class CalculateButton extends JButton
{
	//--------------------------------------
	//Attributes----------------------------
	//--------------------------------------
	TextPanel foodInput;
	TextPanel hotelInput;
	TextPanel transportInput;
	TextPanel incidentalsInput;
	TextPanel totalCostOuput;
	//---------------------------------------
	//Constructors---------------------------
	//---------------------------------------
	public CalculateButton (String name, TextPanel foodIn, TextPanel hotelIn, TextPanel transportIn, TextPanel incidentalsIn, TextPanel totalCostOut)
	{
		super(name);
		
		//Sets pointers to TextPanels
		foodInput = foodIn;
		hotelInput = hotelIn;
		transportInput = transportIn;
		incidentalsInput = incidentalsIn;
		totalCostOuput = totalCostOut;
		
		addActionListener(new MyAction(this));
		setSize(100,30);
		setPreferredSize(new Dimension(100,30));
		setBorder(BorderFactory.createLineBorder(Color.black, 5, true));		
	}
}
class MyAction implements ActionListener
{
	//----------------------------------
	//Attributes------------------------
	//----------------------------------
	double inputText;	
	CalculateButton button = null;
	boolean inputValid = true;
	//----------------------------------
	//Constructors----------------------
	//----------------------------------
	public MyAction(CalculateButton b)
	{
		button = b;
	}

	@Override
	public void actionPerformed(ActionEvent e) throws NumberFormatException
	{
		double totalSum = 0;
		inputToDouble((InputField)button.foodInput.comp);
		totalSum += inputText;
		inputText = 0;
		inputToDouble((InputField)button.hotelInput.comp);
		totalSum += inputText;
		inputText = 0;
		inputToDouble((InputField)button.transportInput.comp);
		totalSum += inputText;
		inputText = 0;
		inputToDouble((InputField)button.incidentalsInput.comp);
		totalSum += inputText;
		inputText = 0;
		/*totalSum += inputToDouble((InputField)button.foodInput.comp);
		totalSum += inputToDouble((InputField)button.hotelInput.comp);
		totalSum += inputToDouble((InputField)button.transportInput.comp);
		totalSum += inputToDouble((InputField)button.incidentalsInput.comp);*/
		if(inputValid)
		{
			((OutputField)button.totalCostOuput.comp).setText(Double.toString(totalSum));
		}
		else
		{
			((OutputField)button.totalCostOuput.comp).setText("");
		}
		
	}
	
	public void inputToDouble(InputField input) throws NumberFormatException 
	{
		try
		{
			inputText = Double.valueOf(input.getText());
			//return Double.valueOf(input.getText());
		}
		catch (NumberFormatException nfe)
		{
			input.setForeground(Color.RED);
			button.totalCostOuput.setBackground(Color.DARK_GRAY);
			((OutputField)button.totalCostOuput.comp).setBackground(Color.DARK_GRAY);
			inputValid = false;
		}
		//return inputText;
	}
	
}


