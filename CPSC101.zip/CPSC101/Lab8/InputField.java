package cpsc101.lab8.heales;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTextField;

public class InputField extends JTextField
{
	//------------------------------------
	//Constructors------------------------
	//------------------------------------
	public InputField()	
	{
		setSize(149,24); 
		setBackground(Color.WHITE); 
		setPreferredSize(new Dimension(149,24));
	}
}
