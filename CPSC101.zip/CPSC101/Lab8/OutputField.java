package cpsc101.lab8.heales;

public class OutputField extends InputField
{
	//-------------------------------------
	//Constructors-------------------------
	//-------------------------------------
	public OutputField()
	{
		super();
		setEditable(false);
	}

}
