package cpsc101.lab8.heales;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Test extends JFrame
{

	public static void main(String[] args) 
	{
		TextPanel foodPanel = new TextPanel(new FlowLayout(FlowLayout.RIGHT), new TextLabel("FOOD", "Enter food costs in CAD"), Color.WHITE);
		TextPanel hotelPanel = new TextPanel(new FlowLayout(FlowLayout.RIGHT), new TextLabel("HOTEL COST", "Enter hotel costs in CAD"), Color.WHITE);
		TextPanel transportPanel = new TextPanel(new FlowLayout(FlowLayout.RIGHT), new TextLabel("TRANSPORTATION", "Enter transportation costs in CAD"),Color.WHITE);
		TextPanel incidentalsPanel = new TextPanel(new FlowLayout(FlowLayout.RIGHT), new TextLabel("INCIDENTALS", "Enter incidental costs in CAD"), Color.WHITE);
		TextPanel costPanel = new TextPanel(new FlowLayout(FlowLayout.RIGHT), new TextLabel("TOTAL COST",""), Color.WHITE);
		
		TextPanel foodInput = new TextPanel(new GridBagLayout(), new InputField(), Color.WHITE);
		TextPanel hotelInput = new TextPanel(new GridBagLayout(), new InputField(), Color.WHITE);
		TextPanel transportInput = new TextPanel(new GridBagLayout(), new InputField(), Color.WHITE);
		TextPanel incidentalInput = new TextPanel(new GridBagLayout(), new InputField(), Color.WHITE);
		TextPanel totalCostOutput = new TextPanel(new GridBagLayout(), new OutputField(), Color.WHITE);
		totalCostOutput.setBackground(Color.WHITE);
		
		JFrame frame = new JFrame();
		
		/*
		frame.add(new TextLabel("FOOD", "Enter food costs in CAD"));
		frame.add(new InputField());
		frame.add(new TextLabel("HOTEL COST", "Enter hotel costs in CAD"));
		frame.add(new InputField());
		frame.add(new TextLabel("TRANSPORTATION", "Enter transportation costs in CAD"));
		frame.add(new InputField());
		frame.add(new TextLabel("INCIDENTALS", "Enter incidental costs in CAD"));
		frame.add(new InputField());
		frame.add(new TextLabel("TOTAL COST", ""));
		*/
		

		JPanel megaPanel = new JPanel(new GridLayout(5,2));
		megaPanel.setSize(350,140);
		megaPanel.setPreferredSize(new Dimension(350,140));
		megaPanel.setOpaque(true);
		megaPanel.setBorder(BorderFactory.createLineBorder(Color.black, 5));
		
		megaPanel.add(foodPanel);
		megaPanel.add(foodInput);
		megaPanel.add(hotelPanel);
		megaPanel.add(hotelInput);
		megaPanel.add(transportPanel);
		megaPanel.add(transportInput);
		megaPanel.add(incidentalsPanel);
		megaPanel.add(incidentalInput);
		megaPanel.add(costPanel);
		megaPanel.add(totalCostOutput);
		
		CalculateButton button = new CalculateButton("CALCULATE", foodInput, hotelInput, transportInput, incidentalInput, totalCostOutput);
		button.setLocation(megaPanel.getX() + 400,megaPanel.getY());
		
		frame.setSize(1000,750);
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame.setLayout(new GridBagLayout());
		
		frame.add(megaPanel);
		frame.add(button);

		frame.setVisible(true);
	}

}
