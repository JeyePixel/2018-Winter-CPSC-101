package cpsc101.lab8.heales;

import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JLabel;

public class TextLabel extends JLabel
{
	//-------------------------------
	//Objects------------------------
	//-------------------------------
	Font labelFont = new Font(Font.SANS_SERIF, Font.BOLD, 12);
	
	//-------------------------------
	//Constructors-------------------
	//-------------------------------
	public TextLabel(String text, String toolTipText)
	{
		setToolTipText(toolTipText);
		setText(text);
		setFont(labelFont);
		setSize(149,24);
		//using setPreferredSize appears to bugger up the text once it's in a Panel
		//Only Panel will use setPreferedSize
		setPreferredSize(new Dimension(149,24));
	}
}
