package cpsc101.lab8.heales;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.LayoutManager;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

public class TextPanel extends JPanel
{
	//------------------------------
	//Constructors------------------
	//------------------------------
	public Component comp;
	public TextPanel(LayoutManager layout, Component comp, Color c)
	{
		super(layout);
		this.comp = comp;
		setSize(150,25);
		setPreferredSize(new Dimension(150,25));
		setBackground(c);
		//setForeground(c); Doesn't change the color of the input area
		//setLayout(null);
		setBorder(BorderFactory.createLineBorder(Color.black));
		setOpaque(true);
		add(comp);
	} 
}
