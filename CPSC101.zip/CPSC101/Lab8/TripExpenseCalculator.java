package cpsc101.lab8.heales;

import java.awt.GridBagLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class TripExpenseCalculator extends JFrame
{
	//-------------------------------------------
	//Constructors-------------------------------
	//-------------------------------------------
	public TripExpenseCalculator()
	{
	}
	public static void main(String[] args)
	{
		TripExpenseCalculator frame = new TripExpenseCalculator();
	}
}
