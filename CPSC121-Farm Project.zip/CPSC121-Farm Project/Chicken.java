package P3;

public class Chicken extends Animal{
	private static int id;
	public Chicken() {
		setName("Chicken" + ++id);
		setMealAmount(5);
	}
	public Chicken(String name, double x, double y, double energy) {
		super(name,x,y,energy);
	}
	public void sound(){
		if(isAlive()) System.out.println("Cluck!");
	}
	public void swim(){
		if(isAlive()) System.out.println("Chicken can swim as following:...!");
	}
}
