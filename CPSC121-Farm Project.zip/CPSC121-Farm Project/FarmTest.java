/*
 * Every time we run this program, we are adding 1 clone to the array of Animals. This means that we will increment the 
 * animal count each time the program is run.
 */

package P3;

public class FarmTest {
	public static void main(String[] args) throws CloneNotSupportedException {
		Farm myFarm = new Farm("farm.txt");
		for(Animal a: myFarm.getAnimals())
			a.setEnergy(Math.random()*100);
		System.out.println("\nAvailable food before feeding: " + myFarm.getAvailableFood() + "\n");
		System.out.println("\nInitial list of animals:\n-------------------------");
		myFarm.printAnimals();
		System.out.println("\nAdding a clone of the second animal\n-----------------------------------\n");
		myFarm.addClone(myFarm.getAnimals()[1]);
		myFarm.printAnimals();
		System.out.println("\nFeeding the animals:\n-----------------------------------\n");
		myFarm.feedAnimals();
		System.out.println("\nAvailable food after feeding: " + myFarm.getAvailableFood() + "\n");
		System.out.println("\nAfter SORTING:\n--------------");
		myFarm.animSort();
		myFarm.printAnimals();
		System.out.println("\nFarm summary:\n--------------");
		myFarm.printSummary();
		myFarm.exit("farm.txt");
	}
}
